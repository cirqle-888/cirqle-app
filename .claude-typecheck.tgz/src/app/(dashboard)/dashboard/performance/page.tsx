import { redirect } from 'next/navigation'
import { createAdminClient } from '@/lib/supabase/server'
import { loadCurrentUser, hasPermission } from '@/lib/permissions/check'
import { PERMS } from '@/lib/permissions/keys'
import type { PerfAssessment, PerfCriterion } from '@/lib/performance/types'
import PerformanceClient from './performance-client'

export const dynamic = 'force-dynamic'

/** Performance Scorecards — score employees and applicants, apply to pay. */
export default async function PerformancePage() {
  const me = await loadCurrentUser().catch(() => null)
  if (me && !me.isAdmin && !hasPermission(me, PERMS.PERFORMANCE_MANAGE)) redirect('/dashboard')

  const admin = createAdminClient()
  const [criteriaRes, employeesRes, applicantsRes, assessmentsRes, scoresRes] = await Promise.all([
    admin.from('perf_criteria').select('*').eq('is_active', true).order('sort'),
    admin.from('employees').select('id, name, cqid, performance_rating')
      .eq('is_active', true).eq('is_archived', false).order('name'),
    admin.from('job_applications').select('id, full_name, position_title, stage')
      .neq('stage', 'rejected').order('created_at', { ascending: false }).limit(100),
    admin.from('perf_assessments').select('*').order('created_at', { ascending: false }).limit(200),
    admin.from('perf_scores').select('assessment_id, criteria_id, value'),
  ])

  return (
    <PerformanceClient
      criteria={(criteriaRes.data ?? []) as PerfCriterion[]}
      employees={(employeesRes.data ?? []) as never[]}
      applicants={(applicantsRes.data ?? []) as never[]}
      assessments={(assessmentsRes.data ?? []) as PerfAssessment[]}
      scores={(scoresRes.data ?? []) as never[]}
    />
  )
}
