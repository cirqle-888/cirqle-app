-- Optional cleanup: retire the advertising AI jobs that already dead-lettered.
-- The code fix stops NEW ones from failing (they now skip gracefully when AI
-- is disabled/unconfigured), but existing 'failed' rows stay until cleared.
-- This marks them cancelled so the Queue Monitoring "Failed" count resets.
UPDATE public.system_jobs
   SET status = 'cancelled', finished_at = now()
 WHERE status = 'failed'
   AND job_type IN ('advertising_recommendation','advertising_executive_summary');
-- See how many remain (should be 0 failed for these types after):
SELECT job_type, status, count(*) FROM public.system_jobs
 WHERE job_type IN ('advertising_recommendation','advertising_executive_summary')
 GROUP BY job_type, status ORDER BY 1,2;
