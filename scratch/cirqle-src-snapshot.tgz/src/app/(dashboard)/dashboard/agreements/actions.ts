'use server'

import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { createAdminClient } from '@/lib/supabase/admin'
import { requirePermission, requireAnyPermission, loadCurrentUser, hasPermission } from '@/lib/permissions/check'
import { recalcTaskCommissions } from '@/lib/sync/integrity'
import { syncFeeLinesForAgreementItem } from '@/lib/agreements/fee-lines'
import { PERMS } from '@/lib/permissions/keys'
import { generateAgreementNumber } from '@/lib/agreements/numbering'
import { logAgreementEvent } from '@/lib/agreements/events'
import { pickVersionForTask, planUnlink, type ItemVersionRow } from '@/lib/agreements/manual-link'
import type {
  AgreementStatus, Visibility, RenewalType, CommitmentType, Cycle, CarryForwardRule,
} from '@/lib/agreements/types'

type ActionResult<T = void> = { ok: true; data?: T } | { ok: false; error: string }

/** Helper to grab current user details for the audit log */
async function getActor() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null

  const { data: emp } = await supabase
    .from('employees')
    .select('id, name')
    .eq('auth_id', user.id)
    .single()

  return emp ? { id: emp.id, name: emp.name } : null
}

export async function createAgreement(input: {
  clientId: string
  title: string
  startDate: string
  endDate?: string | null
  renewalType: RenewalType
  notes?: string
}): Promise<ActionResult<string>> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  if (!input.clientId) return { ok: false, error: 'Select a client' }
  if (!input.title?.trim()) return { ok: false, error: 'Enter an agreement title' }
  if (!input.startDate) return { ok: false, error: 'Pick a start date' }
  if (input.endDate && input.endDate < input.startDate)
    return { ok: false, error: 'End date is before the start date' }

  const supabase = await createClient()

  // Get client code for numbering (column is `code`, not `client_code`).
  const { data: client } = await supabase
    .from('clients')
    .select('code')
    .eq('id', input.clientId)
    .single()

  if (!client) return { ok: false, error: 'Client not found' }

  const creationDate = new Date()
  const { agreementNumber } = await generateAgreementNumber(supabase, creationDate, client.code)

  const { data, error } = await supabase
    .from('client_agreements')
    .insert({
      agreement_number: agreementNumber,
      client_id: input.clientId,
      title: input.title.trim(),
      status: 'draft',
      start_date: input.startDate,
      end_date: input.endDate || null,
      renewal_type: input.renewalType,
      notes: input.notes?.trim() || null,
      created_by: guard.employeeId,
    })
    .select('id')
    .single()

  if (error || !data) return { ok: false, error: error?.message || 'Failed to create agreement' }

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId: data.id,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: 'created',
  })

  revalidatePath('/dashboard/agreements')
  return { ok: true, data: data.id }
}

/** Edit the agreement header (draft-safe fields only — never touches items). */
export async function updateAgreementDetails(
  agreementId: string,
  input: {
    title: string
    startDate: string
    endDate?: string | null
    renewalType: RenewalType
    notes?: string | null
    signedDocumentUrl?: string | null
  },
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  if (!input.title?.trim()) return { ok: false, error: 'Enter an agreement title' }
  if (!input.startDate) return { ok: false, error: 'Pick a start date' }
  if (input.endDate && input.endDate < input.startDate)
    return { ok: false, error: 'End date is before the start date' }

  const supabase = await createClient()
  const { error } = await supabase
    .from('client_agreements')
    .update({
      title: input.title.trim(),
      start_date: input.startDate,
      end_date: input.endDate || null,
      renewal_type: input.renewalType,
      notes: input.notes?.trim() || null,
      signed_document_url: input.signedDocumentUrl || null,
      updated_at: new Date().toISOString(),
    })
    .eq('id', agreementId)

  if (error) return { ok: false, error: error.message }

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: 'updated',
  })

  revalidatePath('/dashboard/agreements')
  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

export async function setAgreementStatus(
  agreementId: string,
  status: AgreementStatus,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()
  const { error } = await supabase
    .from('client_agreements')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', agreementId)

  if (error) return { ok: false, error: error.message }

  let action: any = 'updated'
  if (status === 'active') action = 'activated'
  if (status === 'paused') action = 'paused'
  if (status === 'completed') action = 'completed'
  if (status === 'cancelled') action = 'cancelled'
  if (status === 'expired') action = 'expired'

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action,
    detail: { status },
  })

  revalidatePath('/dashboard/agreements')
  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

/** Soft-delete an agreement (house norm — sets deleted_at). */
export async function deleteAgreement(agreementId: string): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()
  const { error } = await supabase
    .from('client_agreements')
    .update({ deleted_at: new Date().toISOString() })
    .eq('id', agreementId)

  if (error) return { ok: false, error: error.message }

  revalidatePath('/dashboard/agreements')
  return { ok: true }
}

// ─── Items (with nested deliverables + milestones) ───────────────────────────

export interface AgreementDeliverableInput {
  id?: string
  label: string
  content_types: string[]
  committed_quantity: number
  display_order: number
  notes?: string | null
}

export interface AgreementMilestoneInput {
  id?: string
  label: string
  display_order: number
  due_date?: string | null
  visibility: Visibility
}

export interface AgreementItemInput {
  id?: string
  service_id: string | null
  commitment_type: CommitmentType
  committed_quantity: number | null
  cycle: Cycle | null
  effective_from: string
  effective_to?: string | null
  unit_price: number | null
  currency: string
  carry_forward_rule: CarryForwardRule
  extra_unit_price: number | null
  display_order: number
  notes?: string | null
  // Internal retainer allocation (retainer items only). Never client billing.
  creative_allocation_amount?: number | null
  management_allocation_amount?: number | null
  included_quantity?: number | null
  /** Internal per-task value for covered work → contribution pool, never invoiced. */
  work_unit_value?: number | null
  /** Currency the TEAM is paid in for this item's work. Null = item currency. */
  work_unit_currency?: string | null
  /** Employee-pool % for this item's work. null = engine default (50). */
  work_commission_pct?: number | null
  /** Client-facing name on the invoice. null = fall back to the service name. */
  invoice_label?: string | null
  /** Services this retainer item covers (Phase 2b). undefined = leave unchanged. */
  coveredServiceIds?: string[]
  deliverables: AgreementDeliverableInput[]
  milestones: AgreementMilestoneInput[]
}

/** Read the agreement status so we can enforce the draft-only in-place edit rule. */
async function agreementStatus(supabase: any, agreementId: string): Promise<AgreementStatus | null> {
  const { data } = await supabase
    .from('client_agreements')
    .select('status')
    .eq('id', agreementId)
    .single()
  return data?.status ?? null
}

/** Persist an item's own nested deliverables + milestones. */
async function syncItemChildren(
  supabase: any,
  itemId: string,
  deliverables: AgreementDeliverableInput[],
  milestones: AgreementMilestoneInput[],
): Promise<string | null> {
  // Deliverables are pure config (no derived state) → replace wholesale.
  const delDelete = await supabase.from('client_agreement_deliverables').delete().eq('item_id', itemId)
  if (delDelete.error) return delDelete.error.message
  if (deliverables.length > 0) {
    const rows = deliverables.map((d, i) => ({
      item_id: itemId,
      label: d.label.trim(),
      content_types: d.content_types ?? [],
      committed_quantity: Number(d.committed_quantity) || 0,
      display_order: d.display_order ?? i,
      notes: d.notes?.trim() || null,
    }))
    const ins = await supabase.from('client_agreement_deliverables').insert(rows)
    if (ins.error) return ins.error.message
  }

  // Milestones can carry completion state (completed_at / task_id) → upsert by id,
  // delete only the ones the editor removed.
  const { data: existing } = await supabase
    .from('client_agreement_milestones')
    .select('id')
    .eq('item_id', itemId)
  const keepIds = new Set(milestones.map(m => m.id).filter(Boolean) as string[])
  const toDelete = (existing || []).map((m: any) => m.id).filter((id: string) => !keepIds.has(id))
  if (toDelete.length > 0) {
    const del = await supabase.from('client_agreement_milestones').delete().in('id', toDelete)
    if (del.error) return del.error.message
  }
  for (const [i, m] of milestones.entries()) {
    const payload: any = {
      item_id: itemId,
      label: m.label.trim(),
      display_order: m.display_order ?? i,
      due_date: m.due_date || null,
      visibility: m.visibility,
      updated_at: new Date().toISOString(),
    }
    if (m.id) payload.id = m.id
    const up = await supabase.from('client_agreement_milestones').upsert(payload)
    if (up.error) return up.error.message
  }
  return null
}

/**
 * Create a new item, or edit an existing one in place.
 *
 * Doctrine (design §2.3): an active agreement's terms are never UPDATEd in
 * place — a change closes the row and inserts a successor. So in-place edits of
 * an existing item are allowed only while the agreement is draft/pending; use
 * `changeAgreementItemTerms` for active agreements. Adding a brand-new item is
 * always additive and therefore always allowed.
 */
export async function saveAgreementItem(
  agreementId: string,
  item: AgreementItemInput,
  fixDetails = false,
): Promise<ActionResult<string>> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  // Pricing is stripped from the payload sent to a viewer without
  // agreements.view_pricing, so their form round-trips it back as null. Writing
  // that would silently wipe unit_price, currency and the internal allocation
  // the moment such a user edited an item for any other reason. They may edit
  // an item; they may not (re)write its money.
  const me = await loadCurrentUser().catch(() => null)
  const canWritePricing = (me?.isAdmin ?? false) || hasPermission(me, PERMS.AGREEMENTS_VIEW_PRICING)

  if (!item.effective_from) return { ok: false, error: 'Pick an effective-from date' }
  if (item.effective_to && item.effective_to < item.effective_from)
    return { ok: false, error: 'Effective-to date is before effective-from' }

  const supabase = await createClient()
  const status = await agreementStatus(supabase, agreementId)

  if (!fixDetails && item.id && status && status !== 'draft' && status !== 'pending_approval') {
    return {
      ok: false,
      error: 'This agreement is active — edit existing terms through "Change terms" instead.',
    }
  }

  const itemRow = {
    agreement_id: agreementId,
    service_id: item.service_id || null,
    commitment_type: item.commitment_type,
    committed_quantity: item.committed_quantity != null ? Number(item.committed_quantity) : null,
    cycle: item.commitment_type === 'retainer' ? (item.cycle || 'monthly') : null,
    effective_from: item.effective_from,
    effective_to: item.effective_to || null,
    unit_price: item.unit_price != null ? Number(item.unit_price) : null,
    currency: item.currency || 'INR',
    carry_forward_rule: item.carry_forward_rule,
    extra_unit_price: item.extra_unit_price != null ? Number(item.extra_unit_price) : null,
    display_order: item.display_order ?? 0,
    notes: item.notes?.trim() || null,
    // Internal allocation (allocated_unit_value is a GENERATED column)
    creative_allocation_amount:
      item.creative_allocation_amount != null
        ? Number(item.creative_allocation_amount) : null,
    management_allocation_amount:
      item.management_allocation_amount != null
        ? Number(item.management_allocation_amount) : null,
    included_quantity:
      item.included_quantity != null
        ? Number(item.included_quantity) : null,
    work_unit_value: item.work_unit_value != null ? Number(item.work_unit_value) : null,
    work_unit_currency: item.work_unit_currency ?? null,
    work_commission_pct: item.work_commission_pct != null ? Number(item.work_commission_pct) : null,
    invoice_label: item.invoice_label?.trim() || null,
    updated_at: new Date().toISOString(),
  }

  // Omit rather than null: an UPDATE without these keys leaves the stored
  // values untouched. (A brand-new item has nothing to preserve, so the insert
  // below keeps the full row and simply records nulls.)
  const PRICING_KEYS = [
    'unit_price', 'currency', 'extra_unit_price',
    'creative_allocation_amount', 'management_allocation_amount',
    'work_unit_value', 'work_unit_currency', 'work_commission_pct',
  ] as const
  const updateRow: Record<string, unknown> = { ...itemRow }
  if (!canWritePricing) for (const k of PRICING_KEYS) delete updateRow[k]

  let itemId = item.id
  if (itemId) {
    const { error } = await supabase.from('client_agreement_items').update(updateRow).eq('id', itemId)
    if (error) return { ok: false, error: error.message }
  } else {
    const { data, error } = await supabase
      .from('client_agreement_items')
      .insert(itemRow)
      .select('id')
      .single()
    if (error || !data) return { ok: false, error: error?.message || 'Failed to save item' }
    itemId = data.id
  }

  const childErr = await syncItemChildren(supabase, itemId!, item.deliverables || [], item.milestones || [])
  if (childErr) return { ok: false, error: childErr }

  // Covered services (retainer only). undefined ⇒ leave the mapping untouched.
  if (item.coveredServiceIds !== undefined && item.commitment_type === 'retainer') {
    const del = await supabase.from('agreement_item_services').delete().eq('agreement_item_id', itemId!)
    if (del.error) return { ok: false, error: del.error.message }
    const rows = Array.from(new Set(item.coveredServiceIds.filter(Boolean)))
      .map(sid => ({ agreement_item_id: itemId!, service_id: sid }))
    if (rows.length > 0) {
      const ins = await supabase.from('agreement_item_services').insert(rows)
      if (ins.error) return { ok: false, error: ins.error.message }
    }
  }

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: item.id ? 'item_updated' : 'item_added',
  })

  // A changed work value must reach every covered task's stamped
  // work_value_inr and its contribution earnings; a changed fee must reach the
  // open invoices already carrying it. Best-effort: the item is saved either
  // way, the payroll guard inside the recalc skips finalized months, and the
  // fee sync only ever UPDATES existing lines — an edit here never creates an
  // invoice for a month nobody chose to bill.
  if (item.id && canWritePricing) {
    void restampItemWorkValues(item.id).catch(() => {})
    void syncFeeLinesForAgreementItem(createAdminClient(), item.id).catch(() => {})
  }

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true, data: itemId }
}

/**
 * Re-stamp work values for this item's covered tasks, then recalculate their
 * contribution earnings so pay follows the new value.
 *
 * OPEN PAYROLL PERIODS ONLY. The stamp is the basis earnings were computed
 * from, so once a month's payroll is finalized both freeze together and the
 * historical record keeps matching the payslip — the DB function excludes
 * those tasks (migration 20260807150000), and recalcTaskCommissions refuses
 * them independently. Changing an agreement's Work Value therefore never
 * rewrites what someone was already paid, or the figure it was paid from.
 */
async function restampItemWorkValues(itemId: string): Promise<void> {
  const admin = createAdminClient()
  await admin.rpc('restamp_agreement_item_work_values', { p_item_id: itemId })
  const { data: tasks } = await admin
    .from('tasks')
    .select('id')
    .eq('retainer_item_id', itemId)
    .is('deleted_at', null)
  for (const t of tasks || []) {
    // Finalized months are a no-op inside the recalc's own guard.
    try { await recalcTaskCommissions(t.id) } catch { /* per-task best-effort */ }
  }
}

/**
 * Change the terms of an item on an ACTIVE agreement (§2.3 close-and-replace):
 * the current term row is closed the day before `effectiveFrom`, and a
 * successor row carrying the new terms + copied deliverables/milestones is
 * inserted. History for past months therefore resolves the original terms.
 */
export async function changeAgreementItemTerms(
  agreementId: string,
  currentItemId: string,
  newTerms: AgreementItemInput,
): Promise<ActionResult<string>> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  if (!newTerms.effective_from) return { ok: false, error: 'Pick when the new terms take effect' }

  const supabase = await createClient()

  // Close the current row the day before the new terms start.
  const from = new Date(newTerms.effective_from + 'T00:00:00')
  from.setDate(from.getDate() - 1)
  const y = from.getFullYear()
  const m = String(from.getMonth() + 1).padStart(2, '0')
  const d = String(from.getDate()).padStart(2, '0')
  const closeDate = `${y}-${m}-${d}`

  const { data: current } = await supabase
    .from('client_agreement_items')
    .select('effective_from')
    .eq('id', currentItemId)
    .single()
  if (current && newTerms.effective_from <= current.effective_from)
    return { ok: false, error: 'New terms must start after the current term began' }

  const closeRes = await supabase
    .from('client_agreement_items')
    .update({ effective_to: closeDate, updated_at: new Date().toISOString() })
    .eq('id', currentItemId)
  if (closeRes.error) return { ok: false, error: closeRes.error.message }

  // Insert successor (drop the id so a fresh term row is created).
  const successor: AgreementItemInput = { ...newTerms, id: undefined, effective_to: null }
  const res = await saveAgreementItem(agreementId, successor)
  if (!res.ok) return res

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: 'term_changed',
    detail: { from_item_id: currentItemId, to_item_id: res.data },
  })

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return res
}

export async function deleteAgreementItem(
  agreementId: string,
  itemId: string,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()
  const status = await agreementStatus(supabase, agreementId)
  if (status && status !== 'draft' && status !== 'pending_approval')
    return { ok: false, error: 'Items on an active agreement cannot be deleted — change their terms instead.' }

  // Deliverables/milestones cascade via ON DELETE CASCADE.
  const { error } = await supabase.from('client_agreement_items').delete().eq('id', itemId)
  if (error) return { ok: false, error: error.message }

  const actor = await getActor()
  await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: 'item_removed',
  })

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

/** Manually check a milestone off / on (unlinked milestones only). */
export async function toggleMilestone(
  agreementId: string,
  milestoneId: string,
  done: boolean,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()
  const actor = await getActor()
  const { error } = await supabase
    .from('client_agreement_milestones')
    .update({
      completed_at: done ? new Date().toISOString() : null,
      completed_by: done ? actor?.id ?? null : null,
      updated_at: new Date().toISOString(),
    })
    .eq('id', milestoneId)

  if (error) return { ok: false, error: error.message }
  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

export async function addAgreementNote(
  agreementId: string,
  text: string,
  visibility: Visibility,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  if (!text?.trim()) return { ok: false, error: 'Note is empty' }

  const supabase = await createClient()
  const actor = await getActor()

  const ok = await logAgreementEvent(supabase, {
    agreementId,
    actorType: 'admin',
    actorId: actor?.id,
    actorLabel: actor?.name,
    action: 'note',
    visibility,
    detail: { text: text.trim() },
  })

  if (!ok) return { ok: false, error: 'Failed to add note' }

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

export async function linkTaskToAgreementItem(
  agreementId: string,
  itemId: string,
  taskId: string,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()

  // Verify the task exists, is not deleted, and matches the agreement's client.
  const { data: agreement } = await supabase.from('client_agreements').select('client_id').eq('id', agreementId).single()
  if (!agreement) return { ok: false, error: 'Agreement not found' }

  const { data: task } = await supabase.from('tasks').select('client_id, deleted_at').eq('id', taskId).single()
  if (!task) return { ok: false, error: 'Task not found' }
  if (task.deleted_at) return { ok: false, error: 'Cannot link a deleted task' }
  if (task.client_id !== agreement.client_id) return { ok: false, error: 'Task belongs to a different client' }

  const { error } = await supabase.from('client_agreement_tasks').insert({
    item_id: itemId,
    task_id: taskId,
  })

  // 23505 = unique_violation — the join row already exists. NOT a failure:
  // legacy links (and repeated Change-terms duplicates) predate the stamp
  // below, so "already linked" is exactly the state that needs healing.
  // Fall through and stamp; only a genuinely new error aborts.
  if (error && error.code !== '23505') return { ok: false, error: error.message }

  // The join row above is what the agreement screen shows — but every money
  // engine reads tasks.retainer_item_id. Without this stamp a manually linked
  // task LOOKED covered while pooling from billing_amount_inr (0 for covered
  // work), so the team earned nothing from it (task #1902).
  //
  // Only stamp when the engine currently sees nothing: existing coverage —
  // auto-detected retainer coverage or an earlier manual link — always wins,
  // so this can never clobber a task that is already paying correctly.
  //
  // Updating retainer_item_id fires the work-value trigger (BEFORE UPDATE OF
  // retainer_item_id, migration 20260807110000), which stamps work_value_inr
  // from the item's work_unit_value × quantity × fx. It does NOT fire the
  // coverage trigger (client_id / service_id / task_date only), so detection
  // cannot overwrite the stamp in the same write.
  const { data: taskRow } = await supabase
    .from('tasks').select('retainer_item_id, task_date').eq('id', taskId).single()
  if (taskRow && taskRow.retainer_item_id == null) {
    const { data: versions } = await supabase
      .from('client_agreement_items')
      .select('id, agreement_id, service_id, commitment_type, effective_from, effective_to')
      .eq('agreement_id', agreementId)
    const clicked = (versions ?? []).find(v => v.id === itemId)
    const stampId = clicked
      ? pickVersionForTask(clicked as ItemVersionRow, (versions ?? []) as ItemVersionRow[], taskRow.task_date ?? null)
      : itemId
    const { error: stampErr } = await supabase
      .from('tasks').update({ retainer_item_id: stampId }).eq('id', taskId)
    // PostgREST offers no transaction across the two writes; a failed stamp
    // would silently reproduce the old display-only behaviour, so surface it.
    if (stampErr) {
      return { ok: false, error: `Task linked, but coverage could not be applied: ${stampErr.message}. Unlink and retry.` }
    }
    // The pool basis just changed (billing 0 → work value), so the stored
    // scores are stale. recalcTaskCommissions has its own finalized-month
    // guard, matching every other coverage-changing path in this file.
    try { await recalcTaskCommissions(taskId) } catch { /* best-effort */ }
  }

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

export async function unlinkTaskFromAgreementItem(
  agreementId: string,
  itemId: string,
  taskId: string,
): Promise<ActionResult> {
  const guard = await requirePermission(PERMS.AGREEMENTS_MANAGE)
  if (!guard.ok) return guard

  const supabase = await createClient()

  const { error } = await supabase.from('client_agreement_tasks')
    .delete()
    .eq('item_id', itemId)
    .eq('task_id', taskId)

  if (error) return { ok: false, error: error.message }

  // Mirror of the link action's stamp: decide what the removal means for
  // tasks.retainer_item_id. planUnlink's prime rule is that coverage this
  // unlink did not create is never touched — auto-detected retainer coverage
  // and links to other items stand. Only when the task pointed into the
  // unlinked item's lineage does it either move to a surviving manual link or
  // go back to the DB's auto-detection.
  const { data: taskRow } = await supabase
    .from('tasks').select('retainer_item_id, task_date').eq('id', taskId).single()
  if (taskRow?.retainer_item_id) {
    const { data: versions } = await supabase
      .from('client_agreement_items')
      .select('id, agreement_id, service_id, commitment_type, effective_from, effective_to')
      .eq('agreement_id', agreementId)
    const unlinked = (versions ?? []).find(v => v.id === itemId)

    // Items still manually linked to this task after the deletion above.
    const { data: remainingLinks } = await supabase
      .from('client_agreement_tasks').select('item_id').eq('task_id', taskId)
    const remainingIds = new Set((remainingLinks ?? []).map(r => r.item_id))
    const { data: remainingItems } = remainingIds.size > 0
      ? await supabase
          .from('client_agreement_items')
          .select('id, agreement_id, service_id, commitment_type, effective_from, effective_to')
          .in('id', [...remainingIds])
      : { data: [] as ItemVersionRow[] }

    if (unlinked) {
      const plan = planUnlink({
        currentRetainerItemId: taskRow.retainer_item_id,
        unlinked: unlinked as ItemVersionRow,
        allAgreementItems: (versions ?? []) as ItemVersionRow[],
        remainingLinkedItems: (remainingItems ?? []) as ItemVersionRow[],
        taskDate: taskRow.task_date ?? null,
      })
      if (plan.kind === 'restamp') {
        const { error: e } = await supabase
          .from('tasks').update({ retainer_item_id: plan.itemId }).eq('id', taskId)
        if (e) return { ok: false, error: `Unlinked, but coverage could not be updated: ${e.message}` }
        try { await recalcTaskCommissions(taskId) } catch { /* best-effort */ }
      } else if (plan.kind === 'redetect') {
        // A no-op touch of task_date re-fires the DB coverage trigger, which
        // recomputes retainer_item_id from scratch (an auto-covered retainer
        // item, or NULL) and restamps work_value_inr — exactly the state the
        // task would have if the manual link had never existed.
        const { error: e } = await supabase
          .from('tasks').update({ task_date: taskRow.task_date }).eq('id', taskId)
        if (e) return { ok: false, error: `Unlinked, but coverage could not be cleared: ${e.message}` }
        try { await recalcTaskCommissions(taskId) } catch { /* best-effort */ }
      }
    }
  }

  revalidatePath(`/dashboard/agreements/${agreementId}`)
  return { ok: true }
}

export async function searchClientTasks(clientId: string, query: string = '') {
  const guard = await requireAnyPermission([PERMS.TASKS_VIEW_ALL, PERMS.TASKS_VIEW_OWN])
  if (!guard.ok) return { ok: false, error: guard.error }

  const supabase = await createClient()

  let q = supabase.from('tasks')
    .select('id, task_number, title, status, task_date')
    .eq('client_id', clientId)
    .is('deleted_at', null)
    .order('task_date', { ascending: false })
    .limit(30)

  if (query.trim()) {
    const isNum = /^\d+$/.test(query.trim())
    if (isNum) {
      q = q.eq('task_number', parseInt(query.trim(), 10))
    } else {
      q = q.ilike('title', `%${query.trim()}%`)
    }
  }

  const { data, error } = await q
  if (error) return { ok: false, error: error.message }
  return { ok: true, data: data ?? [] }
}
